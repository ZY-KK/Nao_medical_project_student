#!/usr/bin/env python
# -*-coding:utf-8 -*-


from diagnose import diagnose
from keywords_finding import keywords_finding
from medical_tree import node, tree
from speech_recognition_by_Nao import speechToText
from naoqi import ALProxy
import time
from getRemoteFiles import remoteFile
if __name__ == '__main__':
    robot_IP = "192.168.1.106"
    # robot_PORT = 9559
    """create nodes"""
    hospital = node('Hospital')
    internalDepartment = node('Internal Department')
    surgicalDepartment = node('Surgical Department')
    fever = node('fever')
    headache = node('headache')
    blood = node('blood')
    fall = node('fall')
    """connect the nao robot"""
    tts = ALProxy("ALTextToSpeech", robot_IP, 9559)
    record = ALProxy("ALAudioRecorder", robot_IP, 9559)

    """add the value"""
    hospital.addChildren(internalDepartment)
    hospital.addChildren(surgicalDepartment)
    internalDepartment.addChildren(fever)
    internalDepartment.addChildren(headache)
    surgicalDepartment.addChildren(blood)
    surgicalDepartment.addChildren(fall)

    internalDepartment.addFather(hospital)
    surgicalDepartment.addFather(hospital)

    fever.addFather(internalDepartment)
    headache.addFather(internalDepartment)

    blood.addFather(surgicalDepartment)
    fall.addFather(surgicalDepartment)

    tree = tree(hospital)
    #    tree.linktohead(hospital)

    # testcase
    global flag, record_filePath, recognition_result
    record_filePath = ("/home/nao/diagnose_test/record.wav")
    flag = False
    while flag == False:
        stt = speechToText()
        stt.record_Nao(robot_IP, record_filePath)
        downloadFile= remoteFile()
        downloadFile.getRemoteFile("/home/nao/diagnose_test/record.wav", "./diagnose_test/record.wav")
        recognition_result = stt.fileRecognizer("./diagnose_test/record.wav")
        print recognition_result
        tts.say(recognition_result[:-1].encode('utf-8'))
        print "Is the result right, yes or no"
        tts.say("Is the result right, yes or no")
        # downloadFile.getRemoteFile("/home/nao/diagnose_test/judgeResult.wav", "./diagnose_test/judgeResult.wav")
        judgeResultFile = ("/home/nao/diagnose_test/judgeResult.wav")
        channels = [0, 0, 1, 0]

        record.startMicrophonesRecording(judgeResultFile, 'wav', 16000, channels)
        time.sleep(5)

        record.stopMicrophonesRecording()
        print "record over"

        # stt.record_Nao(robot_IP, judgeResultFile)
        downloadFile.getRemoteFile("/home/nao/diagnose_test/judgeResult.wav", "./diagnose_test/judgeResult.wav")
        judgeResult = stt.fileRecognizer("./diagnose_test/judgeResult.wav")
        print judgeResult
        tts.say(judgeResult[:-1].encode('utf-8'))

        if judgeResult == "Yes.":
            flag = True
            keyf = keywords_finding()
            matchWords = keyf.find_keyword(recognition_result[:-1])
            print recognition_result
            word = [matchWord.encode('utf-8') for matchWord in matchWords]
            print word
            diagnoseResult = tree.findFather(hospital, word[0])
            # print diagnoseResult
            dia = diagnose()
            dia.diagnose(diagnoseResult[0], robot_IP, 9559)
        else:
            flag = False








            # print tree.findFather(hospital, "blood")
