#!/usr/bin/env python
# -*-coding:utf-8 -*-

from naoqi import ALProxy
import time

class diagnose:
    #def __init__(self):



    # robot ip address
    # robot_IP = "nao.local"
    # robot_PORT = 9559
    tts = None


    def diagnose(self,physical_conditions, robot_IP, robot_PORT):
        global tts
        tts = ALProxy('ALTextToSpeech', robot_IP, robot_PORT)
        result= 'you can go to '+ physical_conditions
        print  result
        tts.say(result)

