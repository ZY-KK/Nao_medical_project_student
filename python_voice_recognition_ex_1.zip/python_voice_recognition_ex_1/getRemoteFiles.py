#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os
import paramiko
import time

HOST='192.168.1.106'
PORT=22
USERNAME='nao'
PASSWORD='nimdA'
COMMAND='scp /home/nao/diagnose_test/record.wav /diagnose_test/'


class remoteFile:
    def getRemoteFile(self, fileOriginalPath, fileAimPath):
       t=paramiko.Transport((HOST, PORT))
       t.connect(username=USERNAME, password=PASSWORD)

       sftp= paramiko.SFTPClient.from_transport(t)
       sftp.get(fileOriginalPath, fileAimPath)

